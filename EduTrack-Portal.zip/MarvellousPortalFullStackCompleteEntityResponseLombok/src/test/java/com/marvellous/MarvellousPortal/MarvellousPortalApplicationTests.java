package com.marvellous.MarvellousPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarvellousPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
