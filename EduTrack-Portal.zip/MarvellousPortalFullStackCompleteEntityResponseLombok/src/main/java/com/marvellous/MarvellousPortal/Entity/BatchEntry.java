package com.marvellous.MarvellousPortal.Entity;

import lombok.*;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;
@Data
@Document(collection = "BatchDetails")
public class BatchEntry
{
    private ObjectId id;
    private String name;
    private int fees;
}
